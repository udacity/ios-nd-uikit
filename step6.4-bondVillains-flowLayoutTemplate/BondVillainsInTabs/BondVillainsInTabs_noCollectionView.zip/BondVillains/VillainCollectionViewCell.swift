//
//  VillainCollectionViewCell.swift
//  BondVillains
//
//  Created by Gabrielle Miller-Messner on 2/3/15.
//  Copyright (c) 2015 Udacity. All rights reserved.
//

import UIKit

class VillainCollectionViewCell: UICollectionViewCell {
 
    @IBOutlet weak var villainImageView: UIImageView!
    //@IBOutlet weak var nameLabel: UILabel!
    
    //@IBOutlet weak var schemeLabel: UILabel!
    
}
